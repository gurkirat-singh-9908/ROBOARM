import socketio
import time
import sys
import serial
from main import inverse_kinematics
from map import map_sliders_to_servos
import numpy as np
from param import Home_Position, Default_Gripper_Position

port = 'COM6'  # Change to your port (e.g., 'COM6' or '/dev/ttyUSB0')
baud_rate = 9600
# Create a Socket.IO client
sio = socketio.Client()

# Store the latest values
latest_values = {
    'slider_x': Home_Position[0],
    'slider_y': Home_Position[1],
    'slider_z': Home_Position[2],
    'roll': Home_Position[3],
    'pitch': Home_Position[4],
    'yaw': Home_Position[5],
    'slider_gripper': Default_Gripper_Position
}

def send_data_to_arduino(value1, value2):
    """
    Sends two integers to Arduino with a checksum and prints the response.
    
    Args:
        ser: Serial connection object
        value1: First integer to send
        value2: Second integer to send
    """
    checksum = value1 + value2
    command = f"{value1} {value2} {checksum}\n"
    arduino_serial.write(command.encode())  # Send the command as bytes
    time.sleep(0.05)  # Brief delay for Arduino to respond
    response = arduino_serial.readline().decode().strip()  # Read and decode response
    print(f"Sent: {command.strip()}, Received: {response}")

# Serial connection to Arduino
arduino_serial = None

def connect_to_arduino():
    """Connect to Arduino on COM6."""
    global arduino_serial, port
    max_connect_attempts = 3
    for attempt in range(max_connect_attempts):
        try:
            arduino_serial = serial.Serial(port, 9600, timeout=0.2)
            print(f"Connected to Arduino on {port}")
            time.sleep(2)  # Wait for Arduino reset
            #arduino_serial.flushInput()  # Clear input buffer
            #arduino_serial.flushOutput()  # Clear output buffer
            return True
        except (OSError, serial.SerialException) as e:
            print(f"Failed to connect on attempt {attempt + 1}/{max_connect_attempts}: {e}")
            if arduino_serial:
                arduino_serial.close()
                arduino_serial = None
            time.sleep(1)
    print("Warning: Could not connect to Arduino. Running without hardware control.")
    return False

def map_sliders_to_matrix(values):
    """
    Maps all slider values to their corresponding servo angles
    
    Args:
        values (dict): Dictionary containing slider values
    
    Returns:
        dict: Dictionary containing mapped servo angles
    """
    
    # Convert string values to float before mapping
    #try:
    float_values = {
        'slider_x': float(values['slider_x']),
        'slider_y': float(values['slider_y']),
        'slider_z': float(values['slider_z']),
        'roll': float(values['roll']),
        'pitch': float(values['pitch']),
        'yaw': float(values['yaw']),
        'slider_gripper': float(values['slider_gripper'])
    }
    
    # Map each slider to its corresponding servo
    desiredMatrix = np.array([[float_values['slider_x'], float_values['slider_y'], float_values['slider_z']],
                    [float_values['roll'], float_values['pitch'], float_values['yaw']]])
    
    return desiredMatrix

    '''except (ValueError, TypeError) as e:
        print(f"Error converting values to float: {e}")
        print("Values received:", values)
        return None'''

@sio.event
def connect():
    print('Connected to server')

@sio.event
def connect_error(error):
    print(f'Connection failed: {error}')

@sio.event
def disconnect():
    print('Disconnected from server')

@sio.on('value_updated')
def on_value_updated(data):
    param = data.get('param')
    value = data.get('value')
    latest_values[param] = value
    
    # Map slider values to servo angles
    desiredMatrix = map_sliders_to_matrix(latest_values)
    print(">> desiredMatrix =", desiredMatrix)
    servo_angles = inverse_kinematics(desiredMatrix)
    #servo_angles = map_sliders_to_servos(latest_values)

    
    # Send angles to Arduino
    for servo, angle in servo_angles.items():
        servo_number = int(servo[1])  # Extract number (s1 -> 1)
        try:
            intensity = int(round(angle))  # Convert to integer
            #if send_data_to_arduino(servo_number, intensity):
            #    print(f"Servo {servo_number} set to {intensity}°")
            #else:
            #    print(f"Failed to set servo {servo_number} to {intensity}°")
            send_data_to_arduino(servo_number, intensity)
        except ValueError as e:
            print(f"Error for servo {servo_number}: {e}")
    
    # Send gripper value (servo 6)
    gripper_value = float(latest_values['slider_gripper'])
    gripper_angle = int(round((gripper_value / 100) * 180))  # Map 0–100 to 0–180
    try:
        #if send_data_to_arduino(6, gripper_angle):
        #    print(f"Gripper (servo 6) set to {gripper_angle}°")
        #else:
        #    print(f"Failed to set gripper to {gripper_angle}°")
        send_data_to_arduino(servo_number, intensity)
    except ValueError as e:
        print(f"Error for gripper: {e}")

def main():
    try:
        # Connect to Arduino
        arduino_connected = connect_to_arduino()
        if arduino_connected:
            print("Sending initial servo positions...")
            print(f"latest_values{latest_values}")
            desiredMatrix = map_sliders_to_matrix(latest_values)
            print(">> desiredMatrix =", desiredMatrix)
            servo_angles = inverse_kinematics(desiredMatrix)
            #servo_angles = map_sliders_to_servos(latest_values)
            for servo, angle in servo_angles.items():
                servo_number = int(servo[1])
                try:
                    intensity = int(round(angle))
                    #if send_data_to_arduino(servo_number, intensity):
                    #    print(f"Initial: Servo {servo_number} set to {intensity}°")
                    #else:
                    #    print(f"Initial: Failed to set servo {servo_number} to {intensity}°")
                    send_data_to_arduino(servo_number, intensity)
                except ValueError as e:
                    print(f"Initial: Error for servo {servo_number}: {e}")
            
            # Set initial gripper position
            #gripper_value = float(latest_values['slider_gripper'])
            #gripper_angle = int(round((gripper_value / 100) * 180))
            #try:
            #    if send_data_to_arduino(6, gripper_angle):
            #        print(f"Initial: Gripper (servo 6) set to {gripper_angle}°")
            #    else:
            #        print(f"Initial: Failed to set gripper to {gripper_angle}°")
            #except ValueError as e:
            #    print(f"Initial: Error for gripper: {e}")
        else:
            print("Warning: Could not connect to Arduino. Running without hardware control.")
        
        print('Connecting to server...')
        sio.connect('http://localhost:8080', wait_timeout=10)
        sio.wait()
    except Exception as e:
        print(f'Error: {e}')
        print('Ensure Flask server is running on http://localhost:8080')
        if arduino_serial and arduino_serial.is_open:
            arduino_serial.close()
            print("Arduino connection closed")
        sys.exit(1)

if __name__ == '__main__':
    try:
        main()
    finally:
        if arduino_serial and arduino_serial.is_open:
            arduino_serial.close()
            print("Arduino connection closed")