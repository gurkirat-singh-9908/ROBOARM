from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():

    return LaunchDescription([

        Node(
            package="task1",
            executable="object_detector"
        ),

        Node(
            package="task1",
            executable="visual_servo_controller"
        ),

        Node(
            package="task1",
            executable="moveit_interface"
        ),

        Node(
            package="task1",
            executable="arduino_bridge"
        )
    ])
